"""Read-only grasp measurements for an active target and optional destination.

Two-sided pad contact is reported separately from lift and external contacts.
This module chooses no actions and maintains no evolving simulation state.
"""

import numpy as np


class GraspMeasurements:
    def __init__(self, world):
        self.world = world
        self.target = set(world.scene.moving)
        destination = world.config["binding"].get("destination_object")
        self.destination = (
            [
                world.env.sim.model.geom_name2id(n)
                for n in world.env.env.get_object(destination).contact_geoms
            ]
            if destination
            else []
        )
        self.vertices = {
            g: world.scene.local_vertices(g) for g in self.target | set(self.destination)
        }
        bounds = self.bounds(self.target)
        self.initial_bottom_mm = float(bounds[0][2] * 1000)
        left, right = self.pads()
        axis = right.mean(axis=0) - left.mean(axis=0)
        axis /= np.linalg.norm(axis)
        self.open_gap_mm = float(((right @ axis).min() - (left @ axis).max()) * 1000)

    def points(self, ids):
        d = self.world.data
        return np.concatenate(
            [self.vertices[g] @ d.geom_xmat[g].reshape(3, 3).T + d.geom_xpos[g] for g in ids]
        )

    def bounds(self, ids):
        points = self.points(ids)
        return points.min(axis=0), points.max(axis=0)

    def pads(self):
        scene = self.world.scene
        return scene.points(scene.padgroups["left_fingerpad"]), scene.points(
            scene.padgroups["right_fingerpad"]
        )

    def read(self, gripper_contacts):
        w = self.world
        left, right = self.pads()
        center = (left.mean(axis=0) + right.mean(axis=0)) / 2
        axis = right.mean(axis=0) - left.mean(axis=0)
        axis /= np.linalg.norm(axis)
        points = self.points(self.target)
        low, high = points.min(axis=0), points.max(axis=0)
        target_center = (low + high) / 2
        names = {c["hand"] for c in gripper_contacts if c["moving_target"]}
        sides = [
            side
            for side, ids in w.scene.padgroups.items()
            if names & {w.env.sim.model.geom_id2name(g) for g in ids}
        ]
        external = []
        for i in range(w.data.ncon):
            contact = w.data.contact[i]
            a, b = int(contact.geom1), int(contact.geom2)
            if (a in self.target) == (b in self.target):
                continue
            other = b if a in self.target else a
            if other in w.gripper_geoms:
                continue
            force = np.zeros(6)
            w.mujoco.mj_contactForce(w.model, w.data, i, force)
            if force[0] > w.config["contact"]["min_normal_force_N"]:
                external.append(
                    {
                        "other": w.env.sim.model.geom_id2name(other),
                        "normal_force_N": float(force[0]),
                    }
                )
        result = {
            "jaw_center_mm": (center * 1000).tolist(),
            "jaw_axis": axis.tolist(),
            "target_center_mm": (target_center * 1000).tolist(),
            "target_bottom_mm": float(low[2] * 1000),
            "target_top_mm": float(high[2] * 1000),
            "target_lift_mm": float(low[2] * 1000 - self.initial_bottom_mm),
            "target_span_in_jaw_mm": float(np.ptp(points @ axis) * 1000),
            "initial_open_gap_mm": self.open_gap_mm,
            "grasp_alignment_mm": float(np.linalg.norm(target_center - center) * 1000),
            "bilateral_target_contact": len(sides) == 2,
            "target_contact_sides": sides,
            "target_external_contacts": external,
            "target_external_contact_count": len(external),
        }
        if self.destination:
            dest_low, dest_high = self.bounds(self.destination)
            result["destination_top_mm"] = float(dest_high[2] * 1000)
            result["destination_bounds_mm"] = [
                (dest_low * 1000).tolist(),
                (dest_high * 1000).tolist(),
            ]
        return result
